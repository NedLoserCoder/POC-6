'use client';

import CinemaBooking from './components/CinemaBooking';

export default function Home() {
  return (
    <main>
      <CinemaBooking />
    </main>
  );
}
