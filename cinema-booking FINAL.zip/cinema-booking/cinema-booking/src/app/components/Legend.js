export default function Legend() {
  return (
    <div className="legend">
      <div className="legend-item">
        <div className="legend-seat available"></div>
        <span>Disponível</span>
      </div>
      <div className="legend-item">
        <div className="legend-seat selected"></div>
        <span>Selecionado</span>
      </div>
      <div className="legend-item">
        <div className="legend-seat occupied"></div>
        <span>Ocupado</span>
      </div>
    </div>
  );
}
