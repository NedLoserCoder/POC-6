export default function MovieDetails({ movie }) {
  return (
    <div className="movie-details">
      <div className="label">Sinopse:</div>
      <p>{movie.sinopse}</p>
      <div className="label">Data de Lançamento:</div>
      <p>{movie.dataLancamento}</p>
      <div className="label">Direção:</div>
      <p>{movie.direcao}</p>
    </div>
  );
}
