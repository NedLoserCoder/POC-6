export default function SeatGrid({ seats, selectedSeats, toggleSeat }) {
  return (
    <div className="seat-grid">
      {seats.map((seat) => (
        <div
          key={seat.numero}
          className={`seat 
            ${seat.disponivel ? '' : 'occupied'} 
            ${selectedSeats.includes(seat.numero) ? 'selected' : ''}
            ${seat.invisivel ? 'invisivel' : ''}  // Adiciona a classe "invisivel" para assentos invisíveis
          `}
          onClick={() => {
            if (!seat.disponivel || seat.invisivel) return; 
            toggleSeat(seat.numero);
          }}
          style={{
            cursor: seat.disponivel && !seat.invisivel ? 'pointer' : 'not-allowed', 
          }}
          aria-label={`Assento ${seat.numero} ${seat.disponivel ? 'disponível' : 'ocupado'}`}
        />
      ))}
    </div>
  );
}
