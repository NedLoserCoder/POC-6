'use client';

import React, { useState, useEffect } from 'react';
import SeatGrid from './SeatGrid.js';
import MovieDetails from './MovieDetails';
import Legend from './Legend';
import './CinemaBooking.css';

const movieData = {
  titulo: "A Forja",
  sinopse: "Um ano depois de encerrar o ensino médio, o jovem Isaías Wright não tem planos para o futuro e é desafiado por sua mãe solo e um empresário de sucesso a começar a traçar um rumo melhor para sua vida. Ele passa a ser discipulado pelo seu novo mentor, conta com orações de sua mãe e de uma guerreira de orações, Dona Clara, e começa a descobrir o propósito de Deus para sua vida.",
  dataLancamento: "26 de setembro de 2024 (Brasil)",
  direcao: "Alex Kendrick",
  horario: "16:40", 
  preco: 25.0,
  assentos: Array(62)
    .fill()
    .map((_, i) => {
      const novoNumero = i + 1;
      return {
        numero: novoNumero,
        disponivel: ![1, 2, 3, 4, 5, 8, 9, 10, 25, 26, 31, 32, 36, 37].includes(novoNumero), 
        invisivel: [57, 58].includes(novoNumero),  
      };
    }),
};

export default function CinemaBooking() {
  const [theme, setTheme] = useState('light');
  const [selectedSeats, setSelectedSeats] = useState([]);

  useEffect(() => {
    document.body.setAttribute('data-theme', theme);
  }, [theme]);

  const toggleTheme = () => setTheme(theme === 'light' ? 'dark' : 'light');

  const toggleSeat = (seatId) => {
    if (movieData.assentos[seatId]?.invisivel) return;

    setSelectedSeats((prev) =>
      prev.includes(seatId) ? prev.filter((id) => id !== seatId) : [...prev, seatId]
    );
  };

  const totalPrice = selectedSeats.length * movieData.preco;

  return (
    <div className="container">
      <button className="theme-toggle" onClick={toggleTheme}>
        {theme === 'light' ? 'Escuro' : 'Claro'}
      </button>

      <div className="header">
        <h1>{movieData.titulo}</h1>
        <p className="session-time">{movieData.horario}</p>
      </div>

      <div className="content-wrapper">
        <div className="seats-container">
          {Array.isArray(movieData.assentos) && movieData.assentos.length > 0 && (
            <SeatGrid
              seats={movieData.assentos}
              selectedSeats={selectedSeats}
              toggleSeat={toggleSeat}
            />
          )}
          <div className="screen-container">
            <div className="screen-label">Tela</div>
            <div className="screen"></div>
          </div>
          <Legend />
          <div className="buy-section">
            <button
              className="buy-button"
              onClick={() => alert(`Compra bem-sucedida! Total: R$${totalPrice}`)}
            >
              Comprar
              <span className="price-display">R${totalPrice.toFixed(2)}</span>
            </button>
          </div>
        </div>
        <MovieDetails movie={movieData} />
      </div>
    </div>
  );
}
