export const metadata = {
  title: 'Reserva de Assentos no Cinema',
  description: 'Reserve seus assentos para o filme A Forja!',
};


export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
