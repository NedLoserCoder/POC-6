// next.config.mjs
export default {
    reactStrictMode: true, // Ativa o modo estrito do React
    swcMinify: true, // Habilita a minificação de código com o SWC
    images: {
      domains: ['example.com'], // Configuração de domínios de imagens permitidos
    },
    webpack(config) {
      // Exemplo de configuração personalizada do Webpack
      config.module.rules.push({
        test: /\.svg$/,
        use: ['@svgr/webpack'],
      });
  
      return config;
    },
  }
  